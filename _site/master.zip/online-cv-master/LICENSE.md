# Author & License

This Bootstrap template is made by UX/UI designer Xiaoying Riley for developers and is 100% FREE as long as you keep the footer attribution link. You do not have the rights to resell, sublicense or redistribute (even for free) the template on its own or as a separate attachment from any of your work.

If you'd like to use the template without the attribution link, you can buy the commercial license via the theme website
